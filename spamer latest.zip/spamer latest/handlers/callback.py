from telegram import Update
from telegram.ext import ContextTypes
from .start import show_main_menu
from .campaign import (
	create_campaign, show_past_campaigns, campaign_details_handler,
	spam_type_handler, cycle_type_handler, find_by_keywords_handler,
	continue_with_found_chats_handler, add_more_chats_handler, handle_check_payment
)
from .sessions import (
	manage_sessions, add_session_phone, add_session_file, list_sessions,
	delete_sessions_menu, delete_session_confirm
)
from .proxy import (
	manage_proxies, add_proxy, list_proxies, delete_proxy_menu, delete_proxy_confirm
)
from .admin import (
	manage_admins, add_admin, remove_admin, list_admins
)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
	query = update.callback_query
	data = query.data

	# Главная навигация
	if data == 'back_to_main':
		await show_main_menu(update, context)
		return

	# Рассылки: создание, выбор типа, повтор
	if data == 'create_campaign':
		await create_campaign(update, context)
		return
	if data == 'past_campaigns':
		await show_past_campaigns(update, context, page=0)
		return
	if data.startswith('page_'):
		try:
			page = int(data.split('_')[1])
			await show_past_campaigns(update, context, page=page)
		except Exception:
			await show_past_campaigns(update, context, page=0)
		return
	if data.startswith('campaign_'):
		await campaign_details_handler(update, context)
		return
	if data.startswith('spam_type_'):
		await spam_type_handler(update, context)
		return
	if data in ['single_cycle', 'multiple_cycles']:
		await cycle_type_handler(update, context)
		return
	if data == 'find_by_keywords':
		await find_by_keywords_handler(update, context)
		return
	if data == 'continue_with_found_chats':
		await continue_with_found_chats_handler(update, context)
		return
	if data == 'add_more_chats':
		await add_more_chats_handler(update, context)
		return
	if data.startswith('check_payment_'):
		await handle_check_payment(update, context)
		return

	# Сессии
	if data == 'manage_sessions':
		await manage_sessions(update, context)
		return
	if data == 'add_session_phone':
		await add_session_phone(update, context)
		return
	if data == 'add_session_file':
		await add_session_file(update, context)
		return
	if data == 'list_sessions':
		await list_sessions(update, context)
		return
	if data == 'delete_sessions_menu':
		await delete_sessions_menu(update, context)
		return
	if data.startswith('delete_session_'):
		await delete_session_confirm(update, context)
		return

	# Прокси
	if data == 'manage_proxies':
		await manage_proxies(update, context)
		return
	if data == 'add_proxy':
		await add_proxy(update, context)
		return
	if data == 'list_proxies':
		await list_proxies(update, context)
		return
	if data == 'delete_proxy_menu':
		await delete_proxy_menu(update, context)
		return
	if data.startswith('delete_proxy_'):
		await delete_proxy_confirm(update, context)
		return

	# Админка
	if data == 'manage_admins':
		await manage_admins(update, context)
		return
	if data == 'add_admin':
		await add_admin(update, context)
		return
	if data == 'remove_admin':
		await remove_admin(update, context)
		return
	if data == 'list_admins':
		await list_admins(update, context)
		return

	# Неизвестное действие -> в меню
	await show_main_menu(update, context)
