from telegram.ext import ContextTypes
from telegram import Update
from .admin import add_admin, remove_admin, handle_add_admin_input, handle_remove_admin_input
from .sessions import handle_session_file, handle_archive_file, handle_phone_number, handle_auth_code
from .proxy import handle_proxy_input
from .campaign import (
    handle_chats_input, handle_interval_input, handle_message_input,
    handle_cycles_input, handle_cycle_interval_input, handle_keywords_input,
    handle_adding_more_chats, handle_direct_message_input
)
from config import logger

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        if 'state' not in context.user_data:
            return

        state = context.user_data['state']

        state_handlers = {
            'waiting_admin_id': handle_add_admin_input,
            'waiting_admin_remove_id': handle_remove_admin_input,
            'waiting_proxy': handle_proxy_input,
            'waiting_session_file': handle_session_file,
            'waiting_phone': handle_phone_number,
            'waiting_code': handle_auth_code,
            'waiting_interval': handle_interval_input,
            'waiting_chats': handle_chats_input,
            'waiting_keywords': handle_keywords_input,
            'adding_more_chats': handle_adding_more_chats,
            'waiting_message': handle_message_input,
            'waiting_message_direct': handle_direct_message_input,
            'waiting_cycles': handle_cycles_input,
            'waiting_cycle_interval': handle_cycle_interval_input,
        }

        if update.message.document:
            file_name = update.message.document.file_name
            if file_name.lower().endswith(('.zip', '.rar')):
                await handle_archive_file(update, context)
                return
            elif file_name.lower().endswith('.session'):
                 await handle_session_file(update, context)
                 return

        handler = state_handlers.get(state)

        if handler:
            await handler(update, context)

    except Exception as e:
        logger.error(f"Error in handle_message: {str(e)}")
        await update.message.reply_text('Произошла ошибка при обработке сообщения. Пожалуйста, попробуйте еще раз.')
        context.user_data.clear()
        from .start import show_main_menu
        await show_main_menu(update, context)