from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from utils.proxy import load_proxies, remove_proxy_by_index
import socket

async def manage_proxies(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("Добавить прокси", callback_data='add_proxy')],
        [InlineKeyboardButton("Список прокси", callback_data='list_proxies')],
        [InlineKeyboardButton("Удалить прокси", callback_data='delete_proxy_menu')],
        [InlineKeyboardButton("Назад", callback_data='back_to_main')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.callback_query.edit_message_text(
        "🌐 Управление прокси\n\n"
        "Выберите действие:",
        reply_markup=reply_markup
    )

async def add_proxy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    keyboard = [[InlineKeyboardButton("Назад", callback_data='manage_proxies')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.callback_query.edit_message_text(
        "📝 Введите прокси в формате:\n"
        "http:ip:port:username:password\n"
        "или\n"
        "socks5:ip:port:username:password\n\n",
        reply_markup=reply_markup
    )
    context.user_data['state'] = 'waiting_proxy'

async def list_proxies(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    proxies = load_proxies()

    if not proxies:
        await query.edit_message_text(
            "У вас пока нет добавленных прокси",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_proxies')]])
        )
        return

    message = "🌐 Ваши прокси:\n\n"
    for i, proxy in enumerate(proxies, 1):
        message += f"{i}. {proxy}\n"

    keyboard = [[InlineKeyboardButton("Назад", callback_data='manage_proxies')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(message, reply_markup=reply_markup)

async def delete_proxy_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    proxies = load_proxies()

    if not proxies:
        await query.edit_message_text(
            "Список пуст",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_proxies')]])
        )
        return

    keyboard = []
    for i, proxy in enumerate(proxies, 1):
        keyboard.append([InlineKeyboardButton(f"Удалить {i}", callback_data=f'delete_proxy_{i-1}')])
    keyboard.append([InlineKeyboardButton("Назад", callback_data='manage_proxies')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text("Выберите прокси для удаления:", reply_markup=reply_markup)

async def delete_proxy_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    try:
        index = int(data.split('_')[2])
    except Exception:
        await query.answer("Неверный индекс", show_alert=True)
        return
    if remove_proxy_by_index(index):
        await query.edit_message_text(
            "✅ Прокси удален",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_proxies')]])
        )
    else:
        await query.edit_message_text(
            "❌ Не удалось удалить прокси",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_proxies')]])
        )

async def handle_proxy_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    valid_proxies = []
    invalid_proxies = []

    proxy_lines = text.split('\n')

    for proxy in proxy_lines:
        proxy = proxy.strip()
        if not proxy:
            continue

        try:
            parts = proxy.split(':')
            if len(parts) != 5:
                invalid_proxies.append(proxy)
                continue

            proxy_type, ip, port, username, password = parts
            proxy_type = proxy_type.lower()

            if proxy_type not in ['socks5', 'socks4', 'http', 'https']:
                invalid_proxies.append(proxy)
                continue

            try:
                port = int(port)
                if not (0 <= port <= 65535):
                    invalid_proxies.append(proxy)
                    continue
            except ValueError:
                invalid_proxies.append(proxy)
                continue

            try:
                socket.inet_aton(ip)
            except socket.error:
                invalid_proxies.append(proxy)
                continue

            valid_proxies.append(proxy)

        except Exception as e:
            invalid_proxies.append(proxy)
            continue

    if valid_proxies:
        with open('proxy.txt', 'a') as f:
            for proxy in valid_proxies:
                f.write(f"{proxy}\n")

    message = ""
    if valid_proxies:
        message += f"✅ Успешно добавлено {len(valid_proxies)} прокси:\n"
        for proxy in valid_proxies:
            message += f"• {proxy}\n"
        message += "\n"

    if invalid_proxies:
        message += f"❌ Не удалось добавить {len(invalid_proxies)} прокси (неверный формат):\n"
        for proxy in invalid_proxies:
            message += f"• {proxy}\n"

    keyboard = [[InlineKeyboardButton("Назад", callback_data='manage_proxies')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(message, reply_markup=reply_markup)
    context.user_data.pop('state', None)