from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from utils.admin import load_admins, save_admins, is_admin

async def manage_admins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id if update.effective_user else (update.callback_query.from_user.id if update.callback_query else None)
    if not is_admin(user_id): return
    admins = load_admins()
    admin_list = "\n".join([f"• {admin_id}" for admin_id in admins])
    keyboard = [
        [InlineKeyboardButton("➕ Добавить админа", callback_data='add_admin')],
        [InlineKeyboardButton("➖ Удалить админа", callback_data='remove_admin')],
        [InlineKeyboardButton("📋 Список админов", callback_data='list_admins')],
        [InlineKeyboardButton("Назад", callback_data='back_to_main')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    message_text = (
        "👑 Управление администраторами\n\n"
        f"Текущие администраторы:\n{admin_list}\n\n"
        "Выберите действие:"
    )
    if hasattr(update, 'callback_query') and update.callback_query:
        await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(message_text, reply_markup=reply_markup)

async def add_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id if update.effective_user else (update.callback_query.from_user.id if update.callback_query else None)
    if not is_admin(user_id): return
    context.user_data['state'] = 'waiting_admin_id'
    message_text = (
        "➕ Добавление администратора\n\n"
        "Отправьте ID пользователя, которого хотите добавить в администраторы.\n\n"
    )
    reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_admins')]])
    if hasattr(update, 'callback_query') and update.callback_query:
        await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(message_text, reply_markup=reply_markup)

async def remove_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id if update.effective_user else (update.callback_query.from_user.id if update.callback_query else None)
    if not is_admin(user_id): return
    admins = load_admins()
    if len(admins) <= 1:
        if hasattr(update, 'callback_query') and update.callback_query:
            await update.callback_query.answer("❌ Нельзя удалить последнего администратора!", show_alert=True)
        else:
            await update.message.reply_text("❌ Нельзя удалить последнего администратора!")
        return
    context.user_data['state'] = 'waiting_admin_remove_id'
    admin_list = "\n".join([f"• {admin_id}" for admin_id in admins])
    message_text = (
        "➖ Удаление администратора\n\n"
        f"Текущие администраторы:\n{admin_list}\n\n"
        "Отправьте ID администратора, которого хотите удалить:"
    )
    reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_admins')]])
    if hasattr(update, 'callback_query') and update.callback_query:
        await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(message_text, reply_markup=reply_markup)

async def list_admins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id if update.effective_user else (update.callback_query.from_user.id if update.callback_query else None)
    if not is_admin(user_id): return
    admins = load_admins()
    admin_list = "\n".join([f"• {admin_id}" for admin_id in admins])
    message_text = (
        "📋 Список администраторов\n\n"
        f"Текущие администраторы:\n{admin_list}\n\n"
        f"Всего администраторов: {len(admins)}"
    )
    reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_admins')]])
    if hasattr(update, 'callback_query') and update.callback_query:
        await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(message_text, reply_markup=reply_markup)

async def handle_add_admin_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id if update.effective_user else None
    if not is_admin(user_id): return
    text = (update.message.text or "").strip()
    try:
        new_admin_id = int(text)
        admins = load_admins()
        if new_admin_id in admins:
            await update.message.reply_text("ℹ️ Такой админ уже существует.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_admins')]]))
            context.user_data.pop('state', None)
            return
        admins.append(new_admin_id)
        save_admins(admins)
        await update.message.reply_text("✅ Админ добавлен.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_admins')]]))
    except ValueError:
        await update.message.reply_text("❌ Некорректный ID. Введите число.")
        return
    finally:
        context.user_data.pop('state', None)

async def handle_remove_admin_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id if update.effective_user else None
    if not is_admin(user_id): return
    text = (update.message.text or "").strip()
    try:
        remove_id = int(text)
        admins = load_admins()
        if remove_id not in admins:
            await update.message.reply_text("❌ Такого админа нет.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_admins')]]))
            context.user_data.pop('state', None)
            return
        if len(admins) <= 1:
            await update.message.reply_text("❌ Нельзя удалить последнего администратора!", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_admins')]]))
            context.user_data.pop('state', None)
            return
        admins = [a for a in admins if a != remove_id]
        save_admins(admins)
        await update.message.reply_text("✅ Админ удален.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_admins')]]))
    except ValueError:
        await update.message.reply_text("❌ Некорректный ID. Введите число.")
        return
    finally:
        context.user_data.pop('state', None)