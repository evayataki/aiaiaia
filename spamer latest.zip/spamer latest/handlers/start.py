from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from utils.admin import is_admin
from utils.database import track_user

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message_text = (
        "🤖 Добро пожаловать в меню управления рассылкой!\n\n"
        "Выберите действие:"
    )
    user_id = update.effective_user.id if update.effective_user else (update.callback_query.from_user.id if update.callback_query else None)
    keyboard = [
        [InlineKeyboardButton("Создать рассылку", callback_data='create_campaign')],
        [InlineKeyboardButton("Повторить рассылку", callback_data='past_campaigns')],
        [InlineKeyboardButton("Управление сессиями", callback_data='manage_sessions')],
        [InlineKeyboardButton("Управление прокси", callback_data='manage_proxies')]
    ]
    if user_id and is_admin(user_id):
        keyboard.append([InlineKeyboardButton("Управление администраторами", callback_data='manage_admins')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    if update.callback_query:
        await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(message_text, reply_markup=reply_markup)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    # Делаем старт доступным для всех; права админа влияют только на показ кнопки админки
    await track_user(update, context)
    await show_main_menu(update, context)