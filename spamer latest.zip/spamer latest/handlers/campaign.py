import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from utils.database import get_past_campaigns, get_campaign_details
from utils.telegram import search_telegram_groups, create_client_with_proxy
from campaign import start_campaign, handle_check_payment
import config

async def create_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    keyboard = [
        [InlineKeyboardButton("📤 По юзерам", callback_data='spam_type_users')],
        [InlineKeyboardButton("💬 По чатам", callback_data='spam_type_chats')],
        [InlineKeyboardButton("👥 По контактам аккаунта", callback_data='spam_type_contacts')],
        [InlineKeyboardButton("🏠 По чатам где состоит аккаунт", callback_data='spam_type_joined')],
        [InlineKeyboardButton("Вернуться в меню", callback_data='back_to_main')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(
        'Выберите тип рассылки:\n\n'
        '📤 По юзерам - рассылка по списку пользователей\n'
        '💬 По чатам - рассылка по списку чатов/групп\n'
        '👥 По контактам аккаунта - рассылка по контактам аккаунта\n'
        '🏠 По чатам где состоит аккаунт - рассылка по чатам где состоит аккаунт',
        reply_markup=reply_markup
    )

async def show_past_campaigns(update: Update, context: ContextTypes.DEFAULT_TYPE, page=0):
    query = update.callback_query
    campaigns = get_past_campaigns(query.from_user.id)
    items_per_page = 8
    total_pages = (len(campaigns) + items_per_page - 1) // items_per_page
    start_idx = page * items_per_page
    end_idx = start_idx + items_per_page
    current_campaigns = campaigns[start_idx:end_idx]
    keyboard = []
    for campaign_id, campaign_type, start_time, status, chat_count in current_campaigns:
        campaign_type_text = "Один цикл" if campaign_type == "single_cycle" else "Несколько циклов"
        keyboard.append([InlineKeyboardButton(
            f"ID: {campaign_id} | {campaign_type_text} | {start_time} | Чатов: {chat_count}",
            callback_data=f'campaign_{campaign_id}'
        )])
    if total_pages > 1:
        pagination_row = []
        if page > 0:
            pagination_row.append(InlineKeyboardButton("⬅️ Назад", callback_data=f'page_{page-1}'))
        if page < total_pages - 1:
            pagination_row.append(InlineKeyboardButton("Вперед ➡️", callback_data=f'page_{page+1}'))
        keyboard.append(pagination_row)
    keyboard.append([InlineKeyboardButton("Вернуться в меню", callback_data='back_to_main')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(
        f'📋 Выберите рассылку для повторения (Страница {page+1}/{total_pages}):',
        reply_markup=reply_markup
    )

async def campaign_details_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    campaign_id = query.data.split('_')[1]
    campaign = get_campaign_details(campaign_id)
    if campaign:
        context.user_data['campaign_type'] = campaign[1]
        context.user_data['message'] = campaign[2]
        context.user_data['message_type'] = campaign[3]
        context.user_data['media_path'] = campaign[4]
        context.user_data['interval'] = campaign[5] if campaign[5] and int(campaign[5]) >= 1 else config.DEFAULT_INTERVAL
        chats_str = campaign[6].split(',') if campaign[6] else []
        context.user_data['chats'] = []
        for chat in chats_str:
            chat = chat.strip()
            if not chat:
                continue
            if chat.startswith('-') and chat[1:].isdigit():
                context.user_data['chats'].append(int(chat))
            elif chat.isdigit():
                context.user_data['chats'].append(int(chat))
            else:
                context.user_data['chats'].append(chat)
        if campaign[1] == 'multiple_cycles':
            context.user_data['cycles'] = campaign[11] if campaign[11] > 0 else 2
            context.user_data['cycle_interval'] = campaign[12]
        await start_campaign(update, context)

async def spam_type_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    spam_type = query.data.replace('spam_type_', '')
    context.user_data['spam_type'] = spam_type
    keyboard = [
        [InlineKeyboardButton("Один цикл", callback_data='single_cycle')],
        [InlineKeyboardButton("Несколько циклов", callback_data='multiple_cycles')],
        [InlineKeyboardButton("Вернуться в меню", callback_data='back_to_main')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    type_descriptions = {
        'users': '📤 Рассылка по юзерам',
        'chats': '💬 Рассылка по чатам',
        'contacts': '👥 Рассылка по контактам аккаунта',
        'joined': '🏠 Рассылка по чатам где состоит аккаунт'
    }
    await query.edit_message_text(
        f'Выбран тип: {type_descriptions.get(spam_type, spam_type)}\n\n'
        'Теперь выберите тип цикла:',
        reply_markup=reply_markup
    )

async def cycle_type_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    context.user_data['campaign_type'] = query.data
    spam_type = context.user_data.get('spam_type', 'chats')

    if spam_type == 'users':
        reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton("Вернуться в меню", callback_data='back_to_main')]])
        await query.edit_message_text(
            'Введите список пользователей для рассылки:\n'
            '• Пользователи: @username или user_id\n'
            '• Можно вводить через пробел или с новой строки\n\n',
            reply_markup=reply_markup
        )
    elif spam_type == 'chats':
        keyboard = [
            [InlineKeyboardButton("Найти по ключевым словам", callback_data='find_by_keywords')],
            [InlineKeyboardButton("Вернуться в меню", callback_data='back_to_main')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            'Введите список чатов для рассылки:\n'
            '• Группы/каналы: @groupname или https://t.me/groupname\n'
            '• ID чатов: -1001234567890\n\n',
            reply_markup=reply_markup
        )
    elif spam_type in ['contacts', 'joined']:
        reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton("Вернуться в меню", callback_data='back_to_main')]])
        message = (
            'Будет использован список контактов из аккаунта.\n\n' if spam_type == 'contacts' else
            'Будет использован список чатов где состоит аккаунт.\n\n'
        )
        message += (
            '💡 Для рандомизации текста используйте разделители:\n'
            '• ||| - для разделения вариантов\n'
            '• --- - альтернативный разделитель\n'
            '• ### - еще один вариант\n\n'
            'Пример: "Привет!|||Добро пожаловать!|||Здравствуйте!"\n\n'
            'Введите сообщение для рассылки:'
        )
        await query.edit_message_text(message, reply_markup=reply_markup)

    if spam_type in ['contacts', 'joined']:
        context.user_data['state'] = 'waiting_message_direct'
    else:
        context.user_data['state'] = 'waiting_chats'

async def find_by_keywords_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    context.user_data['state'] = 'waiting_keywords'
    keyboard = [[InlineKeyboardButton("Отмена", callback_data='back_to_main')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(
        "Введите ключевые слова для поиска через запятую.\n"
        "Например: бизнес, схемы заработка",
        reply_markup=reply_markup
    )

async def continue_with_found_chats_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    context.user_data['state'] = 'waiting_interval'
    await query.edit_message_text(
        "Сколько секунд ждать между сообщениями? (от 1)"
    )

async def add_more_chats_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    context.user_data['state'] = 'adding_more_chats'
    await query.edit_message_text(
        f"Текущие чаты ({len(context.user_data.get('chats', []))}): \n" +
        ", ".join(str(chat) for chat in context.user_data.get('chats', [])[:10]) +
        ("..." if len(context.user_data.get('chats', [])) > 10 else "") +
        "\n\nВведите дополнительные чаты через пробел:"
    )

async def process_keyword_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from utils.session import get_session_files, validate_session, delete_invalid_session
    try:
        keywords = context.user_data['keywords']
        all_keywords = keywords
        progress_message = "🔍 Начинаю поиск групп по ключевым словам..."
        keyboard = [[InlineKeyboardButton("Отмена", callback_data='back_to_main')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        if update.callback_query:
            await update.callback_query.message.edit_text(progress_message, reply_markup=reply_markup)
        else:
            await update.message.reply_text(progress_message, reply_markup=reply_markup)

        session_files = get_session_files()
        invalid_sessions = []

        if not session_files:
            error_message = "❌ Нет доступных сессий для поиска. Попробуйте позже."
            if update.callback_query: await update.callback_query.message.edit_text(error_message)
            else: await update.message.reply_text(error_message)
            return

        valid_session = None
        for session_file in session_files:
            if await validate_session(session_file):
                valid_session = session_file
                break

        if not valid_session:
            error_message = "❌ Нет валидных сессий для поиска. Попробуйте позже."
            if update.callback_query: await update.callback_query.message.edit_text(error_message)
            else: await update.message.reply_text(error_message)
            return

        try:
            progress_message = "🔍 Поиск групп в процессе, это может занять несколько минут..."
            keyboard = [[InlineKeyboardButton("Отмена", callback_data='back_to_main')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            if update.callback_query:
                await update.callback_query.message.edit_text(progress_message, reply_markup=reply_markup)
            else:
                progress_msg = await update.message.reply_text(progress_message, reply_markup=reply_markup)

            from utils.proxy import get_rotating_proxy
            proxy_config = get_rotating_proxy()
            client = create_client_with_proxy(f'sessions/{valid_session}', proxy_config)

            await client.connect()
            if not await client.is_user_authorized():
                invalid_sessions.append(valid_session)
                error_message = "❌ Сессия недействительна. Попробуйте еще раз позже."
                if update.callback_query: await update.callback_query.message.edit_text(error_message)
                else: await update.message.reply_text(error_message)
                await client.disconnect()
                return

            found_groups, more_invalid_sessions = await search_telegram_groups(client, all_keywords)
            invalid_sessions.extend(more_invalid_sessions)
            await client.disconnect()

            if not found_groups:
                no_results_message = "❌ Не найдено подходящих групп по вашим ключевым словам."
                keyboard = [[InlineKeyboardButton("Назад", callback_data='back_to_main')]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                if update.callback_query: await update.callback_query.message.edit_text(no_results_message, reply_markup=reply_markup)
                else: await update.message.reply_text(no_results_message, reply_markup=reply_markup)
                return

            context.user_data['chats'] = found_groups

            groups_per_message = 50
            groups_chunks = [found_groups[i:i + groups_per_message] for i in range(0, len(found_groups), groups_per_message)]

            first_message = True
            for chunk in groups_chunks:
                chunk_message = "✅ Поиск по ключевым словам завершен!\n\n" if first_message else ""
                chunk_message += "Найденные группы:\n"
                for i, group in enumerate(chunk, 1 if first_message else len(groups_chunks[0]) + 1):
                    chunk_message += f"{i}. @{group}\n"

                if first_message:
                    keyboard = [
                        [InlineKeyboardButton("Продолжить с найденными чатами", callback_data='continue_with_found_chats')],
                        [InlineKeyboardButton("Ввести дополнительные чаты", callback_data='add_more_chats')]
                    ]
                    reply_markup = InlineKeyboardMarkup(keyboard)
                    if update.callback_query: await update.callback_query.message.edit_text(chunk_message, reply_markup=reply_markup)
                    else: await update.message.reply_text(chunk_message, reply_markup=reply_markup)
                    first_message = False
                else:
                    if update.callback_query: await update.callback_query.message.reply_text(chunk_message)
                    else: await update.message.reply_text(chunk_message)

        except Exception as e:
            error_message = "❌ Произошла ошибка при поиске групп. Пожалуйста, попробуйте позже."
            keyboard = [[InlineKeyboardButton("Назад", callback_data='back_to_main')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            if update.callback_query: await update.callback_query.message.edit_text(error_message, reply_markup=reply_markup)
            else: await update.message.reply_text(error_message, reply_markup=reply_markup)

        if invalid_sessions:
            for session in invalid_sessions:
                delete_invalid_session(session)

    except Exception as e:
        error_message = "❌ Произошла ошибка при поиске групп. Пожалуйста, попробуйте позже."
        keyboard = [[InlineKeyboardButton("Назад", callback_data='back_to_main')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        if update.callback_query: await update.callback_query.message.edit_text(error_message, reply_markup=reply_markup)
        else: await update.message.reply_text(error_message, reply_markup=reply_markup)

async def handle_chats_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    chats = []
    lines = text.split('\n')
    for line in lines:
        line = line.strip()
        if not line: continue
        words = line.split()
        for word in words:
            word = word.strip()
            if not word: continue
            if word.startswith('-') and word[1:].isdigit():
                chats.append(int(word))
            elif word.isdigit():
                chats.append(int(word))
            elif word.startswith('https://'):
                chats.append(word)
            elif word.startswith('@'):
                chats.append(word)
            else:
                # Автодобавление @ для username без префикса
                import re
                if re.fullmatch(r"[A-Za-z0-9_]{5,32}", word):
                    chats.append(f"@{word}")
                else:
                    # пропускаем неподходящее слово
                    continue
    context.user_data['chats'] = list(dict.fromkeys(chats))
    await update.message.reply_text('Введите интервал между сообщениями в секундах (минимум 1):')
    context.user_data['state'] = 'waiting_interval'

async def handle_interval_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        interval = int(update.message.text.strip())
        if interval < 1:
            await update.message.reply_text("Должно быть не менее 1 секунды")
            return
        context.user_data['interval'] = interval
        spam_type = context.user_data.get('spam_type', 'chats')
        if spam_type in ['contacts', 'joined'] and context.user_data.get('message'):
            await start_campaign(update, context)
            return
        await update.message.reply_text(
            f"✅ Интервал: {interval} сек\n\n"
            "💡 Для рандомизации текста используйте разделители: |||, ---, ###\n\n"
            "Теперь напиши сообщение для рассылки:"
        )
        context.user_data['state'] = 'waiting_message'
    except ValueError:
        await update.message.reply_text("Введи число от 1")

async def handle_message_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from utils.message import parse_message_variants
    if update.message.photo:
        context.user_data['message_type'] = 'photo'
        file = await update.message.photo[-1].get_file()
        file_path = f"media/{file.file_id}.jpg"
        await file.download_to_drive(file_path)
        context.user_data['media_path'] = file_path
    # ... (handle other media types)
    else:
        context.user_data['message_type'] = 'text'

    context.user_data['message'] = update.message.text or update.message.caption

    if context.user_data['message']:
        variants = parse_message_variants(context.user_data['message'])
        if len(variants) > 1:
            await update.message.reply_text(
                f"✅ Найдено {len(variants)} вариантов сообщения:\n\n" +
                "\n".join([f"{i+1}. {variant}" for i, variant in enumerate(variants)])
            )

    if context.user_data['campaign_type'] == 'multiple_cycles':
        await update.message.reply_text('Введите количество циклов (минимум 2):')
        context.user_data['state'] = 'waiting_cycles'
    else:
        await start_campaign(update, context)

async def handle_direct_message_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from utils.message import parse_message_variants
    if update.message.photo:
        context.user_data['message_type'] = 'photo'
        file = await update.message.photo[-1].get_file()
        file_path = f"media/{file.file_id}.jpg"
        await file.download_to_drive(file_path)
        context.user_data['media_path'] = file_path
    # ... (handle other media types)
    else:
        context.user_data['message_type'] = 'text'

    context.user_data['message'] = update.message.text or update.message.caption

    if context.user_data['message']:
        variants = parse_message_variants(context.user_data['message'])
        if len(variants) > 1:
            await update.message.reply_text(
                f"✅ Найдено {len(variants)} вариантов сообщения:\n\n" +
                "\n".join([f"{i+1}. {variant}" for i, variant in enumerate(variants)])
            )

    await update.message.reply_text('Введите интервал между сообщениями в секундах (минимум 1):')
    context.user_data['state'] = 'waiting_interval'

async def handle_cycles_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        cycles = int(update.message.text)
        if cycles < config.MIN_CYCLES:
            await update.message.reply_text(f'❌ Количество циклов должно быть не менее {config.MIN_CYCLES}. Попробуйте снова:')
            return
        context.user_data['cycles'] = cycles
        await update.message.reply_text('Введите интервал между циклами в минутах (минимум 1):')
        context.user_data['state'] = 'waiting_cycle_interval'
    except ValueError:
        await update.message.reply_text('Пожалуйста, введите число:')

async def handle_cycle_interval_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        interval = int(update.message.text)
        if interval < 1:
            await update.message.reply_text('❌ Интервал между циклами должен быть не менее 1 минуты. Попробуйте снова:')
            return
        context.user_data['cycle_interval'] = interval
        await start_campaign(update, context)
    except ValueError:
        await update.message.reply_text('Пожалуйста, введите число:')

async def handle_keywords_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keywords = [keyword.strip() for keyword in update.message.text.split(',') if keyword.strip()]
    if not keywords:
        await update.message.reply_text('Пожалуйста, введите хотя бы одно ключевое слово:')
        return
    context.user_data['keywords'] = keywords
    await update.message.reply_text(f"🔍 Начинаю поиск чатов по ключевым словам: {', '.join(keywords)}\nЭто может занять некоторое время...")
    asyncio.create_task(process_keyword_search(update, context))

async def handle_adding_more_chats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    additional_chats = []
    lines = text.split('\n')
    for line in lines:
        line = line.strip()
        if not line: continue
        words = line.split()
        for word in words:
            word = word.strip()
            if not word: continue
            if word.startswith('-') and word[1:].isdigit():
                additional_chats.append(int(word))
            elif word.isdigit():
                additional_chats.append(int(word))
            elif word.startswith('https://'):
                additional_chats.append(word)
            elif word.startswith('@'):
                additional_chats.append(word)
            else:
                import re
                if re.fullmatch(r"[A-Za-z0-9_]{5,32}", word):
                    additional_chats.append(f"@{word}")
                else:
                    continue

    context.user_data['chats'].extend(list(dict.fromkeys(additional_chats)))

    keyboard = [[InlineKeyboardButton("Продолжить", callback_data='continue_with_found_chats')]]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        f"✅ Добавлено {len(additional_chats)} чатов.\n"
        f"Всего чатов: {len(context.user_data['chats'])}\n\n"
        f"Нажмите Продолжить, чтобы перейти к настройке интервала.",
        reply_markup=reply_markup
    )
    context.user_data['state'] = 'waiting_message'