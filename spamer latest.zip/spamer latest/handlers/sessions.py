import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from utils.session import get_session_files, validate_session, process_archive_file, safe_delete_session
from utils.proxy import get_rotating_proxy
from utils.telegram import create_client_with_proxy

async def manage_sessions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    keyboard = [
        [InlineKeyboardButton("Добавить по номеру", callback_data='add_session_phone')],
        [InlineKeyboardButton("Добавить файлом", callback_data='add_session_file')],
        [InlineKeyboardButton("Мои сессии", callback_data='list_sessions')],
        [InlineKeyboardButton("Удалить сессии", callback_data='delete_sessions_menu')],
        [InlineKeyboardButton("Назад", callback_data='back_to_main')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(
        "📱 Сессии\n\n"
        "Выбери действие:",
        reply_markup=reply_markup
    )

async def add_session_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    context.user_data['state'] = 'waiting_phone'
    keyboard = [[InlineKeyboardButton("Назад", callback_data='manage_sessions')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(
        "Отправь номер телефона\n",
        reply_markup=reply_markup
    )

async def add_session_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    context.user_data['state'] = 'waiting_session_file'
    keyboard = [[InlineKeyboardButton("Назад", callback_data='manage_sessions')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(
        "Отправь файл сессии (.session)",
        reply_markup=reply_markup
    )

async def list_sessions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    sessions = get_session_files()
    if not sessions:
        await query.edit_message_text(
            "У тебя пока нет сессий",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
        )
        return

    message = "📱 Твои сессии:\n\n"
    for session in sessions:
        message += f"• {session}\n"

    keyboard = [[InlineKeyboardButton("Назад", callback_data='manage_sessions')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(message, reply_markup=reply_markup)

async def delete_sessions_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    sessions = get_session_files()
    if not sessions:
        await query.edit_message_text(
            "Сессий нет",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
        )
        return

    keyboard = []
    for session in sessions:
        keyboard.append([InlineKeyboardButton(f"Удалить {session}", callback_data=f'delete_session_{session}')])
    keyboard.append([InlineKeyboardButton("Назад", callback_data='manage_sessions')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text("Выберите сессию для удаления:", reply_markup=reply_markup)

async def delete_session_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    session_file = data.replace('delete_session_', '')
    try:
        ok = await safe_delete_session(session_file)
        if ok:
            await query.edit_message_text(
                "✅ Сессия удалена",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
            )
        else:
            await query.edit_message_text(
                "❌ Не удалось удалить сессию",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
            )
    except Exception:
        await query.edit_message_text(
            "❌ Ошибка при удалении",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
        )

async def handle_session_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message.document:
        await update.message.reply_text("Отправь файл сессии")
        return

    file = await update.message.document.get_file()
    file_name = update.message.document.file_name

    if not file_name.endswith('.session'):
        await update.message.reply_text("Нужен файл с расширением .session")
        return

    if not os.path.exists('sessions'):
        os.makedirs('sessions')

    file_path = f"sessions/{file_name}"
    await file.download_to_drive(file_path)

    if await validate_session(file_name):
        await update.message.reply_text(
            "✅ Готово!",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
        )
    else:
        os.remove(file_path)
        await update.message.reply_text(
            "❌ Не получилось. Файл удален.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
        )

async def handle_archive_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        file = await update.message.document.get_file()
        file_name = update.message.document.file_name

        if not file_name.lower().endswith(('.zip', '.rar')):
            await update.message.reply_text("❌ Файл должен быть архивом (.zip или .rar)")
            return

        if not os.path.exists('temp_archives'):
            os.makedirs('temp_archives')

        archive_path = f"temp_archives/{file_name}"
        await file.download_to_drive(archive_path)

        await update.message.reply_text("⏳ Обрабатываю архив...")

        result = await process_archive_file(archive_path)

        if result:
            sessions_count = len(result['sessions'])
            json_count = len(result['json_data'])
            total_files = result['total_files']

            message = f"✅ Архив обработан успешно!\n\n"
            message += f"📁 Всего файлов: {total_files}\n"
            message += f"🔑 Валидных сессий: {sessions_count}\n"
            message += f"📄 JSON файлов: {json_count}\n\n"

            if sessions_count > 0:
                message += "Добавленные сессии:\n"
                for session in result['sessions']:
                    message += f"• {session}\n"

            if json_count > 0:
                message += "\nJSON данные:\n"
                for json_file in result['json_data']:
                    message += f"• {json_file['file_name']}\n"

            await update.message.reply_text(
                message,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
            )
        else:
            await update.message.reply_text(
                "❌ Ошибка при обработке архива",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
            )

        try:
            os.remove(archive_path)
        except:
            pass

        context.user_data.pop('state', None)

    except Exception as e:
        await update.message.reply_text("❌ Ошибка при обработке архивного файла")

async def handle_phone_number(update: Update, context: ContextTypes.DEFAULT_TYPE):
    phone = update.message.text.strip()
    if not phone.startswith('+'):
        await update.message.reply_text("Номер должен начинаться с +")
        return

    if not os.path.exists('sessions'):
        os.makedirs('sessions')

    session_name = f"{phone.replace('+', '')}.session"
    session_path = f"sessions/{session_name}"

    try:
        proxy_config = get_rotating_proxy()
        client = create_client_with_proxy(session_path, proxy_config)

        await client.connect()
        if not await client.is_user_authorized():
            await client.send_code_request(phone)
            context.user_data['phone'] = phone
            context.user_data['client'] = client
            context.user_data['state'] = 'waiting_code'
            await update.message.reply_text("Введи код из Telegram")
            return
        else:
            await client.disconnect()
            await update.message.reply_text(
                "✅ Готово!",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
            )
    except Exception as e:
        await update.message.reply_text(
            "❌ Что-то пошло не так",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
        )

async def handle_auth_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    code = update.message.text.strip()
    try:
        client = context.user_data['client']
        await client.sign_in(context.user_data['phone'], code)
        await client.disconnect()
        await update.message.reply_text(
            "✅ Готово!",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
        )
    except Exception as e:
        await update.message.reply_text(
            "❌ Неверный код. Попробуй еще раз",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='manage_sessions')]])
        )