import logging

logger = logging.getLogger(__name__)

def load_admins():
    try:
        with open('admins.txt', 'r', encoding='utf-8') as f:
            return [int(line.strip()) for line in f if line.strip().isdigit()]
    except FileNotFoundError:
        default_admin = 7257685706
        save_admins([default_admin])
        return [default_admin]

def save_admins(admins_list):
    try:
        with open('admins.txt', 'w', encoding='utf-8') as f:
            for admin_id in admins_list:
                f.write(f"{admin_id}\n")
    except Exception as e:
        logger.error(f"Error saving admins list: {str(e)}")

def is_admin(user_id):
    admins = load_admins()
    return user_id in admins