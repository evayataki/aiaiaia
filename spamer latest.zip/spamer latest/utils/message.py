import random

def parse_message_variants(message_text):
    if not message_text:
        return [message_text]
    variants = []
    for separator in ['|||', '---', '###', '***']:
        if separator in message_text:
            variants = [variant.strip() for variant in message_text.split(separator) if variant.strip()]
            break
    if not variants:
        variants = [message_text]
    return variants

def get_random_message_variant(message_text):
    variants = parse_message_variants(message_text)
    return random.choice(variants)

def add_message_randomization(message_text):
    if not message_text:
        return message_text

    random_elements = [
        "🔥", "✨", "💫", "⭐", "🌟", "💎", "🎯", "🚀", "💪", "🎉",
        "😊", "😎", "🤩", "😍", "🥰", "😘", "🤗", "🙌", "👏", "👍"
    ]

    if random.random() < 0.3:
        if random.random() < 0.5:
            message_text = random.choice(random_elements) + " " + message_text
        else:
            message_text = message_text + " " + random.choice(random_elements)

    if random.random() < 0.2:
        if random.random() < 0.5:
            message_text = message_text + "\n"
        else:
            message_text = message_text + " "

    return message_text