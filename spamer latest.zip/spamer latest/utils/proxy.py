import os
import random
import socket
import logging
import threading

logger = logging.getLogger(__name__)

proxy_lock = threading.Lock()
current_proxy_index = 0

def load_proxies():
    try:
        with open('proxy.txt', 'r') as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        return []

def remove_proxy(proxy):
    proxies = load_proxies()
    proxies.remove(proxy)
    with open('proxy.txt', 'w') as f:
        f.write('\n'.join(proxies))

def remove_proxy_by_index(index):
    try:
        proxies = load_proxies()
        if 0 <= index < len(proxies):
            del proxies[index]
            with open('proxy.txt', 'w') as f:
                f.write('\n'.join(proxies))
            return True
        return False
    except Exception as e:
        logger.error(f"Error removing proxy at index {index}: {str(e)}")
        return False

def get_next_proxy():
    global current_proxy_index
    proxies = load_proxies()

    if not proxies:
        return None

    with proxy_lock:
        proxy = proxies[current_proxy_index]
        current_proxy_index = (current_proxy_index + 1) % len(proxies)
        return proxy

def parse_proxy(proxy_string):
    try:
        parts = proxy_string.split(':')
        if len(parts) != 5:
            return None
        proxy_type_str, ip, port, username, password = parts
        proxy_type_str = proxy_type_str.lower()
        if proxy_type_str not in ['socks5', 'socks4', 'http', 'https']:
            return None
        return {
            'proxy_type': proxy_type_str,
            'addr': ip,
            'port': int(port),
            'username': username,
            'password': password,
            'rdns': True
        }
    except Exception as e:
        logger.error(f"Error parsing proxy {proxy_string}: {str(e)}")
        return None

def get_random_proxy():
    proxies = load_proxies()
    if not proxies:
        return None

    proxy_string = random.choice(proxies)
    return parse_proxy(proxy_string)

def get_rotating_proxy():
    proxies = load_proxies()
    if not proxies:
        return None
    proxy_string = get_next_proxy()
    return parse_proxy(proxy_string) if proxy_string else None