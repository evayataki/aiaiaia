import os
import json
import asyncio
import logging
import sqlite3
import time
import zipfile
import rarfile
import threading
from telethon import TelegramClient, errors
from .proxy import get_rotating_proxy
from .telegram import generate_device_info, create_client_with_proxy

logger = logging.getLogger(__name__)

session_locks = {}
session_lock = threading.Lock()
async_session_locks = {}
active_sessions = set()

def get_session_lock(session_file):
    with session_lock:
        if session_file not in session_locks:
            session_locks[session_file] = threading.Lock()
        return session_locks[session_file]

def get_async_session_lock(session_file):
    if session_file not in async_session_locks:
        async_session_locks[session_file] = asyncio.Lock()
    return async_session_locks[session_file]

def get_session_files():
    try:
        sessions_dir = os.path.abspath('sessions')
        if not os.path.exists(sessions_dir):
            return []
        files = [f for f in os.listdir(sessions_dir) if f.endswith('.session')]
        return files
    except Exception as e:
        return []

def extract_archive(archive_path, extract_to='sessions'):
    try:
        if not os.path.exists(extract_to):
            os.makedirs(extract_to)
        extracted_files = []
        if archive_path.lower().endswith('.zip'):
            with zipfile.ZipFile(archive_path, 'r') as zip_ref:
                for file_info in zip_ref.infolist():
                    if file_info.filename.endswith('.session') or file_info.filename.endswith('.json'):
                        zip_ref.extract(file_info, extract_to)
                        extracted_files.append(file_info.filename)
        elif archive_path.lower().endswith('.rar'):
            with rarfile.RarFile(archive_path, 'r') as rar_ref:
                for file_info in rar_ref.infolist():
                    if file_info.filename.endswith('.session') or file_info.filename.endswith('.json'):
                        rar_ref.extract(file_info, extract_to)
                        extracted_files.append(file_info.filename)
        return extracted_files
    except Exception as e:
        return []

def load_json_data(json_file_path):
    try:
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data
    except Exception as e:
        return None

async def process_archive_file(archive_path):
    try:
        extracted_files = extract_archive(archive_path)
        sessions = []
        json_data = []
        for file_name in extracted_files:
            file_path = os.path.join('sessions', file_name)
            if file_name.endswith('.session'):
                if await validate_session(file_name):
                    sessions.append(file_name)
            elif file_name.endswith('.json'):
                data = load_json_data(file_path)
                if data:
                    json_data.append({
                        'file_name': file_name,
                        'data': data
                    })
        return {
            'sessions': sessions,
            'json_data': json_data,
            'total_files': len(extracted_files)
        }
    except Exception as e:
        return None

async def safe_delete_session(session_file):
    try:
        sessions_dir = os.path.abspath('sessions')
        session_path = os.path.join(sessions_dir, session_file)
        session_name = session_file
        try:
            device_info = generate_device_info()
            proxy_config = get_rotating_proxy()
            client = create_client_with_proxy(session_path, proxy_config)
            await client.connect()
            if await client.is_user_authorized():
                me = await client.get_me()
                if me:
                    session_name = f"{me.first_name} (@{me.username})"
            await client.disconnect()
        except Exception as e:
            pass
        for ext in ['', '.session-journal', '.session-wal', '.session-shm']:
            file_path = f"{session_path}{ext}"
            if os.path.exists(file_path):
                for _ in range(3):
                    try:
                        os.remove(file_path)
                        break
                    except Exception as e:
                        time.sleep(1)
        return True
    except Exception as e:
        return False

async def delete_invalid_session(session_file):
    await safe_delete_session(session_file)

async def delete_sessions_batch(session_files):
    if not session_files:
        return
    for session_file in session_files:
        try:
            sessions_dir = os.path.abspath('sessions')
            session_path = os.path.join(sessions_dir, session_file)
            session_name = session_file
            try:
                device_info = generate_device_info()
                proxy_config = get_rotating_proxy()
                client = create_client_with_proxy(session_path, proxy_config)
                await client.connect()
                if await client.is_user_authorized():
                    me = await client.get_me()
                    if me:
                        session_name = f"{me.first_name} (@{me.username})"
                await client.disconnect()
            except Exception as e:
                pass
            for ext in ['', '.session-journal', '.session-wal', '.session-shm']:
                file_path = f"{session_path}{ext}"
                if os.path.exists(file_path):
                    for _ in range(3):
                        try:
                            os.remove(file_path)
                            break
                        except Exception as e:
                            time.sleep(1)
        except Exception as e:
            pass

async def validate_session(session_file, invalid_sessions_list=None):
    client = None
    validation_result = False
    try:
        sessions_dir = os.path.abspath('sessions')
        session_path = os.path.join(sessions_dir, session_file)
        if not os.path.exists(session_path):
            if invalid_sessions_list is not None:
                invalid_sessions_list.append(session_file)
            return False
        file_size = os.path.getsize(session_path)
        if file_size < 1024:
            if invalid_sessions_list is not None:
                invalid_sessions_list.append(session_file)
            return False
        max_retries = 3
        for attempt in range(max_retries):
            try:
                with sqlite3.connect(session_path, timeout=10) as conn:
                    conn.execute("SELECT name FROM sqlite_master WHERE type='table';")
                break
            except sqlite3.DatabaseError as e:
                if attempt == max_retries - 1:
                    if invalid_sessions_list is not None:
                        invalid_sessions_list.append(session_file)
                    return False
                else:
                    time.sleep(1)
        device_info = generate_device_info()
        proxy_config = get_rotating_proxy()
        client = create_client_with_proxy(session_path, proxy_config)
        try:
            await asyncio.wait_for(client.connect(), timeout=15)
            if not client.is_connected():
                if invalid_sessions_list is not None:
                    invalid_sessions_list.append(session_file)
                return False
        except Exception as e:
            if invalid_sessions_list is not None:
                invalid_sessions_list.append(session_file)
            return False
        try:
            me = await client.get_me()
            if me:
                validation_result = True
            else:
                if invalid_sessions_list is not None:
                    invalid_sessions_list.append(session_file)
        except (errors.UnauthorizedError, errors.SessionPasswordNeededError, errors.PhoneNumberBannedError, errors.UserDeactivatedError, errors.UserDeactivatedBanError) as e:
            if invalid_sessions_list is not None:
                invalid_sessions_list.append(session_file)
        except Exception as e:
            if invalid_sessions_list is not None:
                invalid_sessions_list.append(session_file)
        finally:
            if client.is_connected():
                await client.disconnect()
    except Exception as e:
        if invalid_sessions_list is not None:
            invalid_sessions_list.append(session_file)
    finally:
        if client and client.is_connected():
            await client.disconnect()
        return validation_result

def is_session_in_use(session_file):
    return session_file in active_sessions

def mark_session_active(session_file):
    active_sessions.add(session_file)

def mark_session_inactive(session_file):
    active_sessions.discard(session_file)

async def recreate_session(session_file):
    try:
        phone = session_file.replace('.session', '')
        client = TelegramClient(
            f'sessions/{session_file}',
            api_id=os.getenv('API_ID'),
            api_hash=os.getenv('API_HASH')
        )
        await client.connect()
        if not await client.is_user_authorized():
            await client.send_code_request(phone)
            code = input(f'Enter the code for {phone}: ')
            await client.sign_in(phone, code)
        return True
    except Exception as e:
        return False
    finally:
        if 'client' in locals():
            await client.disconnect()