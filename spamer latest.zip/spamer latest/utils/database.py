import sqlite3
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

def init_db():
    conn = sqlite3.connect('campaigns.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS campaigns
                 (id TEXT PRIMARY KEY,
                  campaign_type TEXT,
                  message TEXT,
                  message_type TEXT,
                  media_path TEXT,
                  interval INTEGER,
                  chats TEXT,
                  start_time TEXT,
                  end_time TEXT,
                  status TEXT,
                  user_id INTEGER,
                  cycles INTEGER,
                  cycle_interval INTEGER,
                  current_session TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (user_id INTEGER PRIMARY KEY,
                  username TEXT,
                  first_name TEXT,
                  last_name TEXT,
                  join_date TEXT,
                  last_activity TEXT,
                  total_campaigns INTEGER DEFAULT 0,
                  total_messages INTEGER DEFAULT 0)''')
    c.execute('''CREATE TABLE IF NOT EXISTS broadcasts
                 (id TEXT PRIMARY KEY,
                  start_time TEXT,
                  end_time TEXT,
                  duration REAL,
                  total_users INTEGER,
                  successful_sends INTEGER,
                  failed_sends INTEGER,
                  failed_users TEXT,
                  message_type TEXT)''')
    conn.commit()
    conn.close()

async def track_user(update, context):
    user = update.effective_user
    conn = sqlite3.connect('campaigns.db')
    c = conn.cursor()
    c.execute('SELECT user_id FROM users WHERE user_id = ?', (user.id,))
    if not c.fetchone():
        c.execute('''INSERT INTO users
                    (user_id, username, first_name, last_name, join_date, last_activity)
                    VALUES (?, ?, ?, ?, ?, ?)''',
                 (user.id, user.username, user.first_name, user.last_name,
                  datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                  datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    else:
        c.execute('UPDATE users SET last_activity = ? WHERE user_id = ?',
                 (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), user.id))
    conn.commit()
    conn.close()

def save_campaign_to_db(campaign):
    conn = sqlite3.connect('campaigns.db')
    c = conn.cursor()
    data = (
        campaign['id'],
        campaign['type'],
        campaign.get('message', ''),
        campaign.get('message_type', 'text'),
        campaign.get('media_path', ''),
        campaign.get('interval', 0),
        ','.join(str(chat) for chat in campaign.get('chats', [])),
        campaign.get('start_time', ''),
        campaign.get('end_time', ''),
        campaign.get('status', 'active'),
        campaign.get('user_id', 0),
        campaign.get('cycles', 0),
        campaign.get('cycle_interval', 0),
        campaign.get('current_session', '')
    )
    c.execute('''INSERT OR REPLACE INTO campaigns
                 (id, campaign_type, message, message_type, media_path, interval, chats,
                  start_time, end_time, status, user_id, cycles, cycle_interval, current_session)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', data)
    conn.commit()
    conn.close()

def get_past_campaigns(user_id):
    conn = sqlite3.connect('campaigns.db')
    c = conn.cursor()
    c.execute('''SELECT id, campaign_type, start_time, status,
                LENGTH(chats) - LENGTH(REPLACE(chats, ',', '')) + 1 as chat_count
                FROM campaigns WHERE user_id = ? ORDER BY start_time DESC''', (user_id,))
    campaigns = c.fetchall()
    conn.close()
    return campaigns

def get_campaign_details(campaign_id):
    conn = sqlite3.connect('campaigns.db')
    c = conn.cursor()
    c.execute('SELECT * FROM campaigns WHERE id = ?', (campaign_id,))
    campaign = c.fetchone()
    conn.close()
    return campaign